﻿namespace projeto
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1=new TextBox();
            textBox2=new TextBox();
            label2=new Label();
            pictureBox2=new PictureBox();
            label1=new Label();
            label3=new Label();
            label4=new Label();
            button1=new Button();
            button2=new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location=new Point(244, 263);
            textBox1.Name="textBox1";
            textBox1.Size=new Size(253, 23);
            textBox1.TabIndex=2;
            textBox1.TextChanged+=textBox1_TextChanged;
            textBox1.Enter+=textBox1_Enter;
            textBox1.KeyDown+=textBox1_KeyDown;
            textBox1.Leave+=textBox1_Leave;
            // 
            // textBox2
            // 
            textBox2.Location=new Point(244, 315);
            textBox2.Name="textBox2";
            textBox2.Size=new Size(253, 23);
            textBox2.TabIndex=3;
            textBox2.TextChanged+=textBox2_TextChanged;
            textBox2.Enter+=textBox2_Enter;
            textBox2.KeyDown+=textBox2_KeyDown;
            textBox2.Leave+=textBox1_Leave;
            // 
            // label2
            // 
            label2.AutoSize=true;
            label2.Font=new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor=SystemColors.ControlText;
            label2.Location=new Point(292, 341);
            label2.Name="label2";
            label2.Size=new Size(163, 13);
            label2.TabIndex=4;
            label2.Text="Esqueces-te da palavra-passe?";
            label2.Click+=label2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image=Properties.Resources.cooltext434121878333096;
            pictureBox2.Location=new Point(130, 93);
            pictureBox2.Name="pictureBox2";
            pictureBox2.Size=new Size(524, 73);
            pictureBox2.SizeMode=PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex=8;
            pictureBox2.TabStop=false;
            // 
            // label1
            // 
            label1.AutoSize=true;
            label1.Font=new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location=new Point(325, 194);
            label1.Name="label1";
            label1.Size=new Size(89, 37);
            label1.TabIndex=9;
            label1.Text="Login";
            label1.Click+=label1_Click;
            // 
            // label3
            // 
            label3.AutoSize=true;
            label3.Font=new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location=new Point(244, 245);
            label3.Name="label3";
            label3.Size=new Size(39, 15);
            label3.TabIndex=13;
            label3.Text="Email";
            label3.Click+=label3_Click;
            // 
            // label4
            // 
            label4.AutoSize=true;
            label4.Font=new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location=new Point(244, 297);
            label4.Name="label4";
            label4.Size=new Size(87, 15);
            label4.TabIndex=14;
            label4.Text="Palavra-passe";
            label4.Click+=label4_Click_1;
            // 
            // button1
            // 
            button1.Location=new Point(503, 315);
            button1.Name="button1";
            button1.Size=new Size(27, 23);
            button1.TabIndex=15;
            button1.Text="👀";
            button1.UseVisualStyleBackColor=true;
            button1.Click+=button1_Click;
            // 
            // button2
            // 
            button2.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;
            button2.BackColor=Color.Transparent;
            button2.FlatStyle=FlatStyle.Popup;
            button2.Font=new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor=Color.Indigo;
            button2.Location=new Point(351, 379);
            button2.Name="button2";
            button2.Size=new Size(48, 46);
            button2.TabIndex=16;
            button2.Text="📥";
            button2.TextAlign=ContentAlignment.TopLeft;
            button2.UseVisualStyleBackColor=false;
            button2.Click+=button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions=new SizeF(7F, 15F);
            AutoScaleMode=AutoScaleMode.Font;
            BackColor=Color.MediumPurple;
            ClientSize=new Size(762, 514);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name="Form1";
            Text="Form1";
            Load+=Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Button button1;
        private Button button2;
    }
}