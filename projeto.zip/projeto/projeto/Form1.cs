using static projeto.Form1;

namespace projeto
{
    public partial class Form1 : Form
    {
        public class Utilizador
        {
            public string Email { get; set; }
            public string Senha { get; set; }

            public Utilizador(string email, string senha)
            {
                Email = email;
                Senha = senha;
            }
        }
        private List<Utilizador> utilizadores = new List<Utilizador>();
        private bool showPassword = false;
        public Form1()
        {
            InitializeComponent();

            utilizadores.Add(new Utilizador("anselmodeandrade@gmail.com", "admin"));
            utilizadores.Add(new Utilizador("tomasadmin@sapopt.com", "headadmin"));
           
            if (textBox1 != null && textBox2 != null)
            {
                textBox1.Text = "Email"; // Define o texto da marca d'�gua
                textBox2.Text = "Palavra-passe";
                textBox2.UseSystemPasswordChar = false;
                textBox2.PasswordChar = '\0'; // Altera a propriedade PasswordChar para '\0'
            }
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Email")
            {
                textBox1.Text = "";
            }

        }
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.ForeColor = SystemColors.GrayText; // Define a cor do texto como cinza claro
                textBox1.Text = "Email"; // Define o texto da marca d'�gua
            }

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            textBox1.ForeColor = Color.Black; // Define a cor do texto como preto
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Palavra-passe")
            {
                textBox2.Text = "";

            }

        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                textBox2.ForeColor = SystemColors.GrayText;
                textBox2.Text = "Palavra-passe";
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            textBox2.ForeColor = Color.Black;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Alterna a vari�vel booleana mostrarSenha
                showPassword = !showPassword;

                // Se mostrarSenha � verdadeiro, mostra a senha.
                // Caso contr�rio, esconde a senha.
                if (showPassword)
                {
                    textBox2.PasswordChar = '\0'; // Mostra a senha

                }
                else
                {
                    textBox2.PasswordChar = '*'; // Esconde a senha

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao alternar a exibi��o da senha: " + ex.Message);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Verifica se o email digitado � v�lido
                string email = textBox1.Text?.ToLower() ?? string.Empty;
                if (email != "anselmodeandrade@gmail.com" && email != "tomasadmin@sapopt.com")
                {
                    MessageBox.Show("Email inv�lido");
                    return;
                }

                // Verifica se a senha est� correta
                string senha = textBox2.Text;

                Utilizador utilizador = utilizadores.FirstOrDefault(u => u.Email == email && u.Senha == senha);
                if (utilizador == null)
                {
                    MessageBox.Show("Senha incorreta");
                    return;
                }

                
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro durante o login: " + ex.Message);
            }

        }
    }
}