﻿namespace projeto
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox2=new PictureBox();
            label1=new Label();
            pictureBox1=new PictureBox();
            button2=new Button();
            button1=new Button();
            textBox1=new TextBox();
            textBox2=new TextBox();
            textBox3=new TextBox();
            button3=new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image=Properties.Resources.cooltext434121878333096;
            pictureBox2.Location=new Point(199, 56);
            pictureBox2.Name="pictureBox2";
            pictureBox2.Size=new Size(392, 42);
            pictureBox2.SizeMode=PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex=9;
            pictureBox2.TabStop=false;
            // 
            // label1
            // 
            label1.AutoSize=true;
            label1.FlatStyle=FlatStyle.Flat;
            label1.Font=new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor=Color.Indigo;
            label1.Location=new Point(324, 111);
            label1.Name="label1";
            label1.Size=new Size(147, 47);
            label1.TabIndex=10;
            label1.Text="Balance";
            label1.Click+=label1_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image=Properties.Resources.image_removebg_preview1;
            pictureBox1.Location=new Point(12, 12);
            pictureBox1.Name="pictureBox1";
            pictureBox1.Size=new Size(156, 113);
            pictureBox1.SizeMode=PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex=11;
            pictureBox1.TabStop=false;
            // 
            // button2
            // 
            button2.BackColor=Color.MediumPurple;
            button2.Font=new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location=new Point(426, 268);
            button2.Name="button2";
            button2.Size=new Size(129, 51);
            button2.TabIndex=14;
            button2.Text="Transferir";
            button2.UseVisualStyleBackColor=false;
            button2.Click+=button2_Click;
            button2.KeyDown+=textBox2_KeyDown;
            button2.KeyPress+=textBox3_KeyPress;
            // 
            // button1
            // 
            button1.BackColor=Color.MediumPurple;
            button1.Font=new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location=new Point(240, 268);
            button1.Name="button1";
            button1.Size=new Size(128, 51);
            button1.TabIndex=15;
            button1.Text="Depositar";
            button1.UseVisualStyleBackColor=false;
            button1.Click+=button1_Click;
            button1.KeyDown+=textBox2_KeyDown;
            button1.KeyPress+=textBox3_KeyPress;
            // 
            // textBox1
            // 
            textBox1.Location=new Point(240, 170);
            textBox1.Name="textBox1";
            textBox1.Size=new Size(315, 23);
            textBox1.TabIndex=16;
            textBox1.TextChanged+=textBox1_TextChanged_1;
            // 
            // textBox2
            // 
            textBox2.Location=new Point(250, 239);
            textBox2.Name="textBox2";
            textBox2.Size=new Size(109, 23);
            textBox2.TabIndex=17;
            textBox2.Visible=false;
            textBox2.Click+=button1_Click;
            textBox2.TextChanged+=textBox2_TextChanged;
            textBox2.KeyDown+=textBox2_KeyDown;
            textBox2.KeyPress+=textBox2_KeyPress;
            // 
            // textBox3
            // 
            textBox3.Location=new Point(437, 239);
            textBox3.Name="textBox3";
            textBox3.Size=new Size(109, 23);
            textBox3.TabIndex=18;
            textBox3.Visible=false;
            textBox3.Click+=button2_Click;
            textBox3.KeyDown+=textBox3_KeyDown;
            // 
            // button3
            // 
            button3.BackColor=Color.Red;
            button3.Font=new Font("Stencil", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor=Color.WhiteSmoke;
            button3.Location=new Point(718, 12);
            button3.Name="button3";
            button3.Size=new Size(53, 37);
            button3.TabIndex=19;
            button3.Text="X";
            button3.UseVisualStyleBackColor=false;
            button3.Click+=button3_Click_1;
            // 
            // Form2
            // 
            AutoScaleDimensions=new SizeF(7F, 15F);
            AutoScaleMode=AutoScaleMode.Font;
            BackColor=Color.MediumPurple;
            ClientSize=new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Name="Form2";
            Text="1";
            Load+=Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox pictureBox2;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button2;
        private Button button1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button3;
    }
}