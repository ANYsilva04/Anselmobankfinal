﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            textBox2.Text = "€ ";
            textBox1.Text = "€ 0";
            textBox1.ReadOnly = true;


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            textBox2.Focus();
            ActiveControl = textBox2;

        }



        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void AtualizarSaldo(decimal valorDeposito)
        {
            decimal novoSaldo;
            if (decimal.TryParse(textBox1.Text.Replace("€ ", ""), out novoSaldo))
            {
                novoSaldo += valorDeposito;
                textBox1.Text = "€ " + novoSaldo.ToString();
            }
            else
            {
                MessageBox.Show("Ocorreu um erro atualizar o seu saldo: ");
            }
        }





        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    decimal valorDeposito;
                    if (decimal.TryParse(textBox2.Text.Replace("€", "").Trim(), out valorDeposito))
                    {
                        textBox2.Visible = false;
                        AtualizarSaldo(valorDeposito);

                        // exibe a mensagem de confirmação
                        MessageBox.Show($"Depósito de € {valorDeposito} concluído com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Digite um valor numérico válido.");
                    }
                }
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {

            string simboloEuro = "€ "; // adiciona o símbolo do euro
            textBox3.Text = simboloEuro; // exibe o símbolo do euro na caixa de texto
            textBox3.Visible = true;
            textBox3.Focus();
            ActiveControl = textBox3;

        }
        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                decimal valortransferencia;
                if (decimal.TryParse(textBox3.Text.Replace("€", "").Trim(), out valortransferencia))
                {
                    decimal saldoAtual;
                    if (decimal.TryParse(textBox1.Text.Replace("€", "").Trim(), out saldoAtual))
                    {
                        if (valortransferencia > 0 && valortransferencia <= saldoAtual)
                        {
                            decimal novoSaldo = saldoAtual - valortransferencia;
                            textBox1.Text = "€ " + novoSaldo.ToString();
                            textBox3.Visible = false;
                            MessageBox.Show($"Transferência de € {valortransferencia} concluída com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("Valor de transferência inválido.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao ler o saldo atual.");
                    }
                }
                else
                {
                    MessageBox.Show("Digite um valor numérico válido.");
                }
            }
        }


        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string simboloEuro = "€ ";
            textBox3.Text = simboloEuro;
            textBox3.Visible = true;
            textBox3.Focus();
            ActiveControl = textBox3;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
